package pe.edu.upeu.sysalmacen.servicio;

import pe.edu.upeu.sysalmacen.modelo.MediaFile;

public interface IMediaFileService extends ICrudGenericoService<MediaFile, Long>{
}
