package pe.edu.upeu.sysasistencia.servicio;

import pe.edu.upeu.sysasistencia.modelo.Acceso;

import java.io.Serializable;

public interface AccesoService extends CrudGenericoService<Acceso, Long> {
}
