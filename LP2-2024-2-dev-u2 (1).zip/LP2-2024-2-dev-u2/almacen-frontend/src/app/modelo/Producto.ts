export class Producto {
  idProducto: number
  nombre: string
  pu: number
  puOld: number
  utilidad: number
  stock: number
  stockOld: number
  categoria: number
  marca: number
  unidadMedida: number
}
