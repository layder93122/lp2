export class Marca {
  idMarca: number
  nombre: string
}
