export const environment = {
  HOST:'http://localhost:8080',
  RETRY: 2,
  TOKEN_NAME: 'access_token'
};
